---
name: release-notes
use-it-when: When asked what shipped
---
# Release notes

Write the notes from the merged pull requests.