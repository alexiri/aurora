## What Daneel does

Triage pull requests and hand them to the right reviewer.

Made with Save as template on 2026-11-24. Accounts, secrets and conversations are not included.
