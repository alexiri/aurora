---
key: queue-notes
updated: "2026-11-01T09:00:00Z"
locked: true
---
The team's queue drains after standup.